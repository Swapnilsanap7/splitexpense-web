'use client';

import { useAuth } from '@/app/context/AuthContext';
import { motion } from 'framer-motion';
import { Caveat } from 'next/font/google';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';

const caveat = Caveat({ subsets: ['latin'], weight: '700' });

export default function Navbar() {
  const { user, logout, isLoginOpen, setIsLoginOpen } = useAuth(); // ✅ Get global login state
  const pathname = usePathname();
  const [isHovered, setIsHovered] = useState(false);

  const toggleLogin = () => {
    setIsLoginOpen(true); // ✅ Trigger login box animation
    setTimeout(() => {
      setIsLoginOpen(false); // ✅ Auto-close after 2 sec
    }, 2000);
  };

  return (
    <>
      <nav className="fixed w-full top-0 z-50 flex items-center py-4 px-8 bg-transparent backdrop-blur-xs">
        {/* Logo */}
        <Link href="/" className={`font-bold text-3xl ${caveat.className}`}>
          SpliteXpense
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-6 ml-auto">
          {/* ✅ Restored Features Button */}
          <button
            onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
            className="hover:text-blue-500 transition"
          >
            Features
          </button>
          
          {/* Contact Page Link */}
          <Link href="/contact" className="hover:text-blue-500 transition">
            Contact
          </Link>

          {/* 🔥 Hide "Login" button if user is logged in OR on dashboard */}
                  {!user && pathname !== "/dashboard" && (
                    <motion.button
                      onClick={toggleLogin}
                      onMouseEnter={() => setIsHovered(true)}
                      onMouseLeave={() => {
                        setIsHovered(false);
                        setIsLoginOpen(false);
                      }}
                      animate={isLoginOpen ? { scale: 1.1 } : { scale: 1 }}
                      transition={{ type: 'spring', stiffness: 150, damping: 15 }}
                      className="bg-blue-500 text-white py-2 px-4 rounded"
                    >
                      Login
                    </motion.button>
                  )}
          
                  {/* 🔹 Logout Button (Only When Logged In) */}
                  {user && pathname === "/dashboard" && (
                    <button onClick={logout} className="bg-red-500 text-white py-2 px-4 rounded">
                      Logout
                    </button>
                  )}
        </div>
      </nav>
    </>
  );
}
